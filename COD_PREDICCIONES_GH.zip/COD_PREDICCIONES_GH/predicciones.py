# CLASE 7 MÓDELO PREDICITIVO CON REGRESIÓN LINEAL SIMPLE
# Proyecto: Homicidios en Colombia

import pandas as pd # Librería para trabajos con tablas
import matplotlib.pyplot as plt # Librería para graficar
from sklearn.linear_model import LinearRegression # Modelo de regresión lineal
import os # Librería para manejo de archivos

ARCHIVO = "HOMICIDIO_20260922.csv" 
SALIDA = "graficas_prediccion"
MOSTRAR_GRAFICAS = True
os.makedirs(SALIDA, exist_ok=True) # Crear carpeta de salida si no existe

ANIO_FUTURO_CORTO = 2027 # Predicción a un año
ANIO_FUTURO_LARGO = 2036 # Predicción a diez años
ANIO_INICIO = 2018

# 1. SELECCIONAR LAS VARIABLES X y Y

print("\n--- 1. SELECCIONAR LAS VARIABLES X y Y ---\n")
print("X: Año en que ocurrió el hecho.")
print("Y: Número de homicidios ocurridos en ese año (suma la columna cantidad).")

# 2. LIMPIAR Y AGRUPAR

print("\n--- 2. LIMPIAR Y AGRUPAR ---\n")   

df = pd.read_csv("HOMICIDIO_20260922.csv", delimiter=",") # Leer archivo CSV

df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_", regex=False) # Nombres de columnas sin espacios, en minúscula, y cambia los esoacios de en medio por guión bajo.

df["departamento"] = df["departamento"].str.strip().str.upper() # Texto en mayúscula y sin espacios sobrantes para que "Risaralda" y "RISARALDA" sean lo mismo.

df["spoa_caracterización"] = df["spoa_caracterizacion"].str.strip().str.upper() # Para que sean lo mismo

df["cantidad"] = pd.to_numeric(df["cantidad"]) # Para sumar la cantidad tiene que ser numérica.

fechas = pd.to_datetime(df["fecha_hecho"], format="%d/%m/%Y", errors="coerce") # Convertir a formato fecha
if fechas.isna().all():
    fechas = pd.to_datetime(df["fecha_hecho"], format="%Y/%m/%d", errors="coerce") # Intentar otro formato si el primero falla.
df["fecha_hecho"] = fechas # Reemplazar la columna original con la columna convertida a fecha.

print("Filas sin fecha valida:", df["fecha_hecho"].isna().sum())
df = df.dropna(subset=["fecha_hecho"]) # No se pueden ubicar en un año, asi que se descartan.
df["año"] = df["fecha_hecho"].dt.year # Extraer el año de la fecha

print("Rango de fechas:", df["fecha_hecho"].min().date(), "->", df["fecha_hecho"].max().date()) # Muestra el rango de fechas del dataset, min la mas antigua, max la mas receiente.

ultimo_anio = int(df["año"].max()) # Último año del dataset.
print(f"El año {ultimo_anio} está incompleto, no se usa para entrenar.")
print(f"El modelo se entrena con los años {ANIO_INICIO} a {ultimo_anio-1}.")

# Subconjunto de datos para las dos predicciones

risaralda = df[df["departamento"] == "RISARALDA"] # Solo los casos de Risaralda.
print(df["departamento"].unique()[:10])
print("Filas de Risaralda:", len(risaralda))

# FUNCION: AGRUPAR, ENTRENAR, EVALUAR, PREDECIR Y GRAFICAR
# Las dos predicciones siguen los mismos pasos, por eso se hace una función para no repetir código.

# Entrena la regresión lineal y devuelve un diccionario con los resultados.

def regresion_por_anio(datos, titulo, nombre_archivo, anio_inicio, color="#1F4E79", graficar=True):

    # Agrupo: victimas por año (se suma "cantidad", no se cuentan filas).
   
    por_anio = datos.groupby("año")["cantidad"].sum().reset_index() 

    # Entrenamiento con años completos y desde el año de inicio elegido.

    entrenamiento = por_anio[(por_anio["año"] >= anio_inicio) & (por_anio["año"] < ultimo_anio)] 

    x = entrenamiento[["año"]] # Variable independiente
    y = entrenamiento["cantidad"] # Variable dependiente (víctimas).

    # Creo el modelo y lo entreno.

    modelo = LinearRegression()
    modelo.fit(x, y) # Entrenamiento del modelo.

    # r2: qué tan bien se ajust la recta ) 1 = perfecto, 0 = no explica nada

    r2 = modelo.score(x,y)

    # Error promedio sobre los años con los que se entrena.

    y_pred = modelo.predict(x)
    error_medio = (abs(y - y_pred)).mean()

    # Predicciones a futuro (max).

    futuros = pd.DataFrame({"año": [ANIO_FUTURO_CORTO, ANIO_FUTURO_LARGO]})
    pred = modelo.predict(futuros)
    pred_corto = max(0, int(pred[0]))
    pred_largo = max(0, int(pred[1]))

    print(f"\n--- Resultados: {titulo} (entrenado desde {anio_inicio}) ---")
    print(f"Pendiente: {modelo.coef_[0]:.2f} víctimas por año")  
    print(f"Intercepto: {modelo.intercept_:.2f}")
    print(f"R2: {r2:.3f}")  
    print(f"Error promedio sobre los datos de entrenamiento: {error_medio:.0f} víctimas")
    print(f"Predicción {ANIO_FUTURO_CORTO}: {pred_corto:,} víctimas")
    print(f"Predicción {ANIO_FUTURO_LARGO}: {pred_largo:,} víctimas")

    # Línea de tendencia desde el primer año de entrenamiento hasta el futuro lejano.
    
    anios_linea = pd.DataFrame({"año": range(int(entrenamiento["año"].min()), ANIO_FUTURO_LARGO + 1)})
    linea = [max(0, v) for v in modelo.predict(anios_linea)]

    if graficar:
        plt.figure(figsize=(11,5))

        # Años anteriores al entrenamiento, en color gris para dar contexto.

        antes = por_anio[por_anio["año"] < anio_inicio]
        if len(antes) > 0:
            plt.scatter(antes["año"], antes["cantidad"], color="gray", s=40, alpha=0.6, label="Años no usados para entrenar")
        plt.scatter(x, y, color=color, s=70, label="Datos históricos (años completos)")
        plt.plot(anios_linea["año"], linea, color="crimson", linewidth=2.5, label="Línea de tendencia (modelo)")
        plt.scatter([ANIO_FUTURO_CORTO, ANIO_FUTURO_LARGO], [pred_corto, pred_largo],
                    color="#C55A11", s=140, marker="*", zorder=5, label="Predicciones")
        plt.annotate(f"{pred_corto:,}", (ANIO_FUTURO_CORTO, pred_corto), textcoords="offset points", xytext=(0, 12), ha="center")
        plt.annotate(f"{pred_largo:,}", (ANIO_FUTURO_LARGO, pred_largo), textcoords="offset points", xytext=(0, 12), ha="center")
        plt.title(f"{titulo}\nEntrenado con {int(entrenamiento["año"].min())}-{int(entrenamiento["año"].max())}")
        plt.xlabel("Año")
        plt.ylabel("Víctimas")
        plt.legend()
        plt.grid(True, linestyle="--", alpha=0.5)
        plt.tight_layout()
        plt.savefig(os.path.join(SALIDA, nombre_archivo), dpi=150)

    return {"modelo": modelo, "r2": r2, "error_medio": error_medio,
            "pendiente": modelo.coef_[0], "pred_corto": pred_corto, "pred_largo": pred_largo,
            "por_anio": por_anio}

# 3 y 4 ENTRENAR Y PREDECIR (Dos Predicciones)

print("\n--- 3 y 4 PREDICCIÓN 1: TOTAL NACIONAL ---")
res_pais = regresion_por_anio(
    df, "Predicción de víctimas de homicidio por año (Colombia)",
    "prediccion_nacional_2018.png", ANIO_INICIO)

print("\n--- 3 y 4 PREDICCIÓN 2: RISARALDA ---")
res_risa = regresion_por_anio(
    risaralda, "Predicción de víctimas de homicidio por año (Risaralda)",
    "prediccion_risaralda_2018.png", ANIO_INICIO, color="#2E8B57")

feminicidios = df[df["spoa_caracterizacion"] == "FEMINICIDIO"]
regresion_por_anio(feminicidios, "Predicción de feminicidios por año (Colombia)",
                    "predicción_feminicidios.png", ANIO_INICIO, color="#8B3A8B")

# 5. EVALUAR EL MODELO

print("\n--- 5. EVALUAR EL MODELO ---")
print()
print("\n5.1 Prueba con el pasado (entrenar hasta 2022 y predecir 2023-2025)")
filas_prueba = []
for nombre, datos in [("Colombia", df), ("Risaralda", risaralda)]:
    serie = datos.groupby("año")["cantidad"].sum().reset_index()
    entren = serie[(serie["año"] >= ANIO_INICIO) & (serie["año"] <= 2022)]
    prueba = serie[(serie["año"] >= 2023) & (serie["año"] < ultimo_anio)]

    m = LinearRegression().fit(entren[["año"]], entren["cantidad"])
    prueba = prueba.copy()
    prueba["predicho"] = m.predict(prueba[["año"]]).round().astype(int)
    prueba["error_%"] = ((prueba["predicho"] - prueba["cantidad"]).abs() / prueba["cantidad"] * 100).round(1)
    print(f"\n{nombre}:")
    filas_prueba.append((nombre, prueba["error_%"].mean()))
    print(f"Error porcentual promedio: {prueba['error_%'].mean():.1f}%")

print("\n5.2 Comparación: se entrena con todo el historico desde 2003")
print()
res_pais_2003 = regresion_por_anio(
    df, "Predicción de víctimas de homicidio por año (Colombia)",
    "predicción_nacional_2003.png", 2003)
res_risa_2003 = regresion_por_anio(
    risaralda, "Predicción de año de homicidio por año (Risaralda)",
    "predicción_risaralda_2003.png", 2003, color="#2E8B57")

print("\n Por qué se eligió 2018:")
print()
print("Las víctimas bajaron hasta 2017-2020 y desde 2021 volvieron a subir.")
print("Una sola recta con todo el histórico sigue la bajada y por eso, en Risaralda llega a predecir 0 víctimas hacia 2036, lo cual no es creíble.")

# Gráfica de comparación Colombia 2003 vs 2018

por_anio_pais = res_pais["por_anio"]
completos = por_anio_pais[por_anio_pais["año"] < ultimo_anio]
anios_linea = pd.DataFrame({"año": range(2003, ANIO_FUTURO_LARGO + 1)})
plt.figure(figsize=(11,5))
plt.scatter(completos["año"], completos["cantidad"], color="#1F4E79", s=50, label="Datos históricos")
plt.plot(anios_linea["año"], [max(0, v) for v in res_pais_2003["modelo"].predict(anios_linea)],
         color="gray", linestyle="--", linewidth=2, label="Modelo con todo el histórico (2003-2025)") 
anios_linea2 = pd.DataFrame({"año": range(ANIO_INICIO, ANIO_FUTURO_LARGO + 1)})
plt.plot(anios_linea2["año"], res_pais["modelo"].predict(anios_linea2),
         color="crimson", linewidth=2.5, label=f"Modelo desde {ANIO_INICIO}")
plt.title("Colombia: efecto de elegir el período de entrenamiento")
plt.xlabel("Año")
plt.ylabel("Víctimas")
plt.legend()
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(SALIDA, "comparación_periodos.png"), dpi=150)

# GRÁFICA APARTE: PROYECCIÓN A 10 AÑOS (2026-2036)
# Usa los modelos entrenados desde ANIO_INICIO y estima cada año hasta 2036.
print("\n--- PROYECCIÓN A 10 AÑOS ---\n")

# Años a proyectar: desde el último año del archivo hasta ANIO_FUTURO_LARGO.
# El 2026 se proyecta completo (el archivo solo llega hasta agosto).
anios_proyeccion = pd.DataFrame({"año": range(ultimo_anio, ANIO_FUTURO_LARGO + 1)})

tabla_proyeccion = pd.DataFrame({"año": anios_proyeccion["año"]})
tabla_proyeccion["colombia"] = [max(0, int(v)) for v in res_pais["modelo"].predict(anios_proyeccion)]
tabla_proyeccion["risaralda"] = [max(0, int(v)) for v in res_risa["modelo"].predict(anios_proyeccion)]
print(tabla_proyeccion.to_string(index=False))
tabla_proyeccion.to_csv("proyeccion_10_anios.csv", index=False, encoding="utf-8-sig")

fig, ejes = plt.subplots(2, 1, figsize=(11, 9))  # Dos gráficas, una encima de la otra.

for eje, nombre, res, color, columna in [
        (ejes[0], "Colombia", res_pais, "#1F4E79", "colombia"),
        (ejes[1], "Risaralda", res_risa, "#2E8B57", "risaralda")]:

    historico = res["por_anio"]
    historico = historico[(historico["año"] >= ANIO_INICIO) & (historico["año"] < ultimo_anio)]

    # Línea continua: datos reales. Línea punteada: lo que estima el modelo.
    eje.plot(historico["año"], historico["cantidad"], marker="o", color=color, linewidth=2, label="Datos reales")
    eje.plot(tabla_proyeccion["año"], tabla_proyeccion[columna], marker="*", markersize=11,
             linestyle="--", color="#C55A11", linewidth=2, label="Proyección del modelo")
    eje.axvspan(ultimo_anio - 0.5, ANIO_FUTURO_LARGO + 0.5, color="#C55A11", alpha=0.07)  # Zona de proyección.

    # Escribo el valor de cada año proyectado encima de su punto.
    for _, fila in tabla_proyeccion.iterrows():
        eje.annotate(f"{int(fila[columna]):,}", (fila["año"], fila[columna]),
                     textcoords="offset points", xytext=(0, 10), ha="center", fontsize=8)

    eje.set_title(f"{nombre}: proyección de víctimas a 10 años (hasta {ANIO_FUTURO_LARGO})")
    eje.set_ylabel("Víctimas")
    eje.set_xlabel("Año")
    eje.set_xticks(range(ANIO_INICIO, ANIO_FUTURO_LARGO + 1))
    eje.legend(loc="upper left")
    eje.grid(True, linestyle="--", alpha=0.5)

plt.tight_layout()
plt.savefig(os.path.join(SALIDA, "proyeccion_10_anios.png"), dpi=150)

# 6. JUSTIFICACIÓN Y LIMITACIONES

print("\n--- 6. JUSTIFICACIÓN Y LIMITACIONES ---\n")
print()
print(f"""
Por qué son relevantes esas predicciones?
- Colombia: estima hacia dónde va el número total de víctimas. Esto sirve para orientar políticas de seguridad
  y asignar recursos (policía, prevención, justicia).
- Risaralda: su tendencia propia puede ser distinta a la del país y es útil para las autoridades locales (pendiente Colombia: {res_pais['pendiente']:+.0f} por año |
  Risaralda: {res_risa['pendiente']:+.0f} por año).

LIMITACIONES
- La regresión lineal simple asume una línea recta; los fenómenos sociales no siempre se comportan así. Por eso es el período de entrenamiento cambia mucho el resultado. 
- Solo se usa el año como variable: no se consideran política de seguridad, economía, conflicto armado, acuerdos de paz ni la pandemia de 2020.
- Con {ANIO_INICIO} como inicio solo hay {ultimo_anio - ANIO_INICIO} puntos de entrenamiento, pocos para una recta.
- Entre más lejos el año predicho (2036 vs 2027), menos confiable el valor.
- Son registros oficiales: pueden tener casos sin información o mal clasificados.
- El último año ({ultimo_anio}) está incompleto y no se incluyó en el entrenamiento.""")

# GUARDAR TABLA DE RESULTADOS

resumen = pd.DataFrame({
    "zona": ["Colombia", "Risaralda"],
    f"pendiente_desde_{ANIO_INICIO}": [res_pais["pendiente"], res_risa["pendiente"]],
    f"r2_desde_{ANIO_INICIO}": [res_pais["r2"], res_risa["r2"]],
    f"prediccion_{ANIO_FUTURO_CORTO}": [res_pais["pred_corto"], res_risa["pred_corto"]],
    f"prediccion_{ANIO_FUTURO_LARGO}": [res_pais["pred_largo"], res_risa["pred_largo"]],
    "pendiente_desde_2003": [res_pais_2003["pendiente"], res_risa_2003["pendiente"]],
    "r2_desde_2003": [res_pais_2003["r2"], res_risa_2003["r2"]],
    f"prediccion_{ANIO_FUTURO_CORTO}_desde_2003": [res_pais_2003["pred_corto"], res_risa_2003["pred_corto"]],
    f"prediccion_{ANIO_FUTURO_LARGO}_desde_2003": [res_pais_2003["pred_largo"], res_risa_2003["pred_largo"]],
    "error_prueba_pasado_%": [filas_prueba[0][1], filas_prueba[1][1]],
}) 
resumen.to_csv("resultados_prediccion.csv", index=False, encoding="utf-8-sig")
print("Tabla de resultados guardada en resultados_prediccion.csv")
print("Gráficas guardadas en la carpeta:", SALIDA)

if MOSTRAR_GRAFICAS:
    print("Abriendo las gráficas... cierra las  ventanas para terminar el programa.")
    plt.show()
